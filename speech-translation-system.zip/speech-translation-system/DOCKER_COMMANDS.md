# Docker Commands Reference

This document provides the correct Docker commands for managing the Speech Translation System. **All docker-compose commands must be run from the `docker/` directory.**

## 🚨 Important Note

The `docker-compose.yml` file is located in the `docker/` subdirectory, so you must either:
1. Navigate to the docker directory first: `cd docker`
2. Or use the full path: `cd docker && docker-compose [command]`

## 📁 Directory Structure

```
speech-translation-system/
├── docker/                    ← docker-compose.yml is here
│   ├── docker-compose.yml     ← Main configuration file
│   ├── start.bat             ← Windows startup script
│   ├── stop.bat              ← Windows stop script
│   └── whisper/              ← Whisper service files
└── [other files...]
```

## 🚀 Starting Services

### Option 1: Using Batch Scripts (Windows - Recommended)
```cmd
cd docker
start.bat
```

### Option 2: Manual Docker Compose
```bash
# Navigate to docker directory first
cd docker

# Start all services in background
docker-compose up -d

# Or start with build (first time or after changes)
docker-compose up -d --build
```

## 🛑 Stopping Services

### Option 1: Using Batch Scripts (Windows)
```cmd
cd docker
stop.bat
```

### Option 2: Manual Docker Compose
```bash
cd docker
docker-compose down
```

## 📊 Monitoring Services

### Check Service Status
```bash
cd docker
docker-compose ps
```

Expected output:
```
NAME                    COMMAND                  SERVICE             STATUS              PORTS
n8n-speech-translation  "tini -- /usr/local/…"   n8n                 running             0.0.0.0:5678->5678/tcp
whisper-api            "uvicorn main:app --…"   whisper-api         running             0.0.0.0:8000->8000/tcp
```

### View Logs
```bash
cd docker

# View all logs
docker-compose logs

# View specific service logs
docker-compose logs n8n
docker-compose logs whisper-api

# Follow logs in real-time
docker-compose logs -f

# Follow specific service logs
docker-compose logs -f whisper-api
```

### Health Checks
```bash
# Check n8n health
curl http://localhost:5678/healthz

# Check Whisper API health
curl http://localhost:8000/health

# Check available languages
curl http://localhost:8000/languages
```

## 🔄 Service Management

### Restart Services
```bash
cd docker

# Restart all services
docker-compose restart

# Restart specific service
docker-compose restart whisper-api
docker-compose restart n8n
```

### Rebuild Services
```bash
cd docker

# Rebuild all services
docker-compose build

# Rebuild specific service
docker-compose build whisper-api

# Rebuild and restart
docker-compose up -d --build
```

### Update Services
```bash
cd docker

# Pull latest images
docker-compose pull

# Restart with new images
docker-compose down
docker-compose up -d
```

## 🧹 Cleanup Commands

### Remove Stopped Containers
```bash
cd docker
docker-compose down
```

### Remove Containers and Volumes
```bash
cd docker
docker-compose down -v
```

### Clean Up Docker System
```bash
# Remove unused containers, networks, images
docker system prune

# Remove everything (use with caution)
docker system prune -a
```

## 🔍 Troubleshooting Commands

### Check Container Details
```bash
cd docker

# Inspect specific container
docker-compose exec whisper-api /bin/bash
docker-compose exec n8n /bin/bash

# Check container resource usage
docker stats
```

### Debug Network Issues
```bash
cd docker

# Check networks
docker network ls

# Inspect the n8n network
docker network inspect docker_n8n-network
```

### Check Volumes
```bash
cd docker

# List volumes
docker volume ls

# Inspect n8n data volume
docker volume inspect docker_n8n_data
```

## 📋 Common Command Patterns

### Full System Reset
```bash
cd docker
docker-compose down -v
docker-compose up -d --build
```

### Quick Restart
```bash
cd docker
docker-compose restart
```

### View Recent Logs
```bash
cd docker
docker-compose logs --tail=50 -f
```

### Check Service Health
```bash
cd docker
docker-compose ps
curl http://localhost:5678/healthz
curl http://localhost:8000/health
```

## ⚠️ Common Errors and Solutions

### Error: "no configuration file provided: not found"
**Problem**: Running docker-compose from wrong directory
**Solution**: Always run from the `docker/` directory
```bash
cd docker
docker-compose ps
```

### Error: "Cannot connect to the Docker daemon"
**Problem**: Docker Desktop not running
**Solution**: Start Docker Desktop first
```bash
# Check if Docker is running
docker info
```

### Error: "port is already allocated"
**Problem**: Ports 5678 or 8000 are in use
**Solution**: Check what's using the ports
```bash
# Windows
netstat -an | findstr :5678
netstat -an | findstr :8000

# Linux/Mac
lsof -i :5678
lsof -i :8000
```

### Error: "service 'whisper-api' failed to build"
**Problem**: Build error in Whisper service
**Solution**: Check build logs and rebuild
```bash
cd docker
docker-compose build --no-cache whisper-api
docker-compose logs whisper-api
```

## 🎯 Best Practices

1. **Always use the docker directory**: `cd docker` before running docker-compose commands
2. **Use batch scripts on Windows**: They handle directory navigation automatically
3. **Check logs for errors**: Use `docker-compose logs` to diagnose issues
4. **Monitor resource usage**: Use `docker stats` to check CPU/memory usage
5. **Regular cleanup**: Periodically run `docker system prune` to free up space
6. **Health checks first**: Always verify services are healthy before troubleshooting

## 📞 Getting Help

If you encounter issues:

1. **Check service status**: `cd docker && docker-compose ps`
2. **View logs**: `cd docker && docker-compose logs -f`
3. **Verify health**: `curl http://localhost:8000/health`
4. **Restart services**: `cd docker && docker-compose restart`
5. **Full reset**: `cd docker && docker-compose down && docker-compose up -d`

Remember: The key is to always run docker-compose commands from the `docker/` directory! 🐳