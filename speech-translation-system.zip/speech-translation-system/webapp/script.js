class SpeechTranslationApp {
    constructor() {
        this.mediaRecorder = null;
        this.audioChunks = [];
        this.recordingTimer = null;
        this.recordingStartTime = null;
        this.currentAudioBlob = null;
        this.selectedFile = null;
        
        // Configuration
        this.n8nWebhookUrl = 'http://localhost:5678/webhook/speech-translate';
        
        this.initializeElements();
        this.attachEventListeners();
        this.checkMicrophonePermission();
    }
    
    initializeElements() {
        // Get all DOM elements
        this.elements = {
            targetLanguage: document.getElementById('targetLanguage'),
            startRecording: document.getElementById('startRecording'),
            stopRecording: document.getElementById('stopRecording'),
            playRecording: document.getElementById('playRecording'),
            recordingStatus: document.getElementById('recordingStatus'),
            recordingTimer: document.getElementById('recordingTimer'),
            audioPlayback: document.getElementById('audioPlayback'),
            fileUploadArea: document.getElementById('fileUploadArea'),
            audioFileInput: document.getElementById('audioFileInput'),
            selectedFile: document.getElementById('selectedFile'),
            fileName: document.getElementById('fileName'),
            removeFile: document.getElementById('removeFile'),
            processAudio: document.getElementById('processAudio'),
            resultsSection: document.getElementById('resultsSection'),
            originalText: document.getElementById('originalText'),
            translatedText: document.getElementById('translatedText'),
            detectedLanguage: document.getElementById('detectedLanguage'),
            targetLanguageDisplay: document.getElementById('targetLanguageDisplay'),
            copyOriginal: document.getElementById('copyOriginal'),
            copyTranslated: document.getElementById('copyTranslated'),
            saveTranslation: document.getElementById('saveTranslation'),
            loadingIndicator: document.getElementById('loadingIndicator'),
            statusMessages: document.getElementById('statusMessages')
        };
    }
    
    attachEventListeners() {
        // Recording controls
        this.elements.startRecording.addEventListener('click', () => this.startRecording());
        this.elements.stopRecording.addEventListener('click', () => this.stopRecording());
        this.elements.playRecording.addEventListener('click', () => this.playRecording());
        
        // File upload
        this.elements.fileUploadArea.addEventListener('click', () => this.elements.audioFileInput.click());
        this.elements.fileUploadArea.addEventListener('dragover', (e) => this.handleDragOver(e));
        this.elements.fileUploadArea.addEventListener('dragleave', (e) => this.handleDragLeave(e));
        this.elements.fileUploadArea.addEventListener('drop', (e) => this.handleFileDrop(e));
        this.elements.audioFileInput.addEventListener('change', (e) => this.handleFileSelect(e));
        this.elements.removeFile.addEventListener('click', () => this.removeSelectedFile());
        
        // Process audio
        this.elements.processAudio.addEventListener('click', () => this.processAudio());
        
        // Result actions
        this.elements.copyOriginal.addEventListener('click', () => this.copyToClipboard(this.elements.originalText.value));
        this.elements.copyTranslated.addEventListener('click', () => this.copyToClipboard(this.elements.translatedText.value));
        this.elements.saveTranslation.addEventListener('click', () => this.saveTranslation());
        
        // Language selection
        this.elements.targetLanguage.addEventListener('change', () => this.updateTargetLanguageDisplay());
    }
    
    async checkMicrophonePermission() {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            stream.getTracks().forEach(track => track.stop());
            this.showStatus('Microphone access granted', 'success');
        } catch (error) {
            this.showStatus('Microphone access denied. File upload will still work.', 'warning');
            this.elements.startRecording.disabled = true;
        }
    }
    
    async startRecording() {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ 
                audio: {
                    echoCancellation: true,
                    noiseSuppression: true,
                    autoGainControl: true
                }
            });
            
            this.mediaRecorder = new MediaRecorder(stream, {
                mimeType: 'audio/webm;codecs=opus'
            });
            
            this.audioChunks = [];
            this.recordingStartTime = Date.now();
            
            this.mediaRecorder.ondataavailable = (event) => {
                if (event.data.size > 0) {
                    this.audioChunks.push(event.data);
                }
            };
            
            this.mediaRecorder.onstop = () => {
                this.currentAudioBlob = new Blob(this.audioChunks, { type: 'audio/webm' });
                this.elements.audioPlayback.src = URL.createObjectURL(this.currentAudioBlob);
                this.elements.audioPlayback.style.display = 'block';
                this.elements.playRecording.disabled = false;
                this.elements.processAudio.disabled = false;
                this.updateProcessButtonText();
                
                // Stop all tracks
                stream.getTracks().forEach(track => track.stop());
            };
            
            this.mediaRecorder.start(1000); // Collect data every second
            
            // Update UI
            this.elements.startRecording.disabled = true;
            this.elements.stopRecording.disabled = false;
            this.elements.recordingStatus.textContent = 'Recording...';
            
            // Start timer
            this.startRecordingTimer();
            
            this.showStatus('Recording started', 'success');
            
        } catch (error) {
            console.error('Error starting recording:', error);
            this.showStatus('Failed to start recording: ' + error.message, 'error');
        }
    }
    
    stopRecording() {
        if (this.mediaRecorder && this.mediaRecorder.state === 'recording') {
            this.mediaRecorder.stop();
            
            // Update UI
            this.elements.startRecording.disabled = false;
            this.elements.stopRecording.disabled = true;
            this.elements.recordingStatus.textContent = 'Recording completed';
            
            // Stop timer
            this.stopRecordingTimer();
            
            this.showStatus('Recording stopped', 'success');
        }
    }
    
    playRecording() {
        if (this.elements.audioPlayback.src) {
            this.elements.audioPlayback.play();
        }
    }
    
    startRecordingTimer() {
        this.recordingTimer = setInterval(() => {
            const elapsed = Date.now() - this.recordingStartTime;
            const minutes = Math.floor(elapsed / 60000);
            const seconds = Math.floor((elapsed % 60000) / 1000);
            this.elements.recordingTimer.textContent = 
                `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        }, 1000);
    }
    
    stopRecordingTimer() {
        if (this.recordingTimer) {
            clearInterval(this.recordingTimer);
            this.recordingTimer = null;
        }
    }
    
    handleDragOver(e) {
        e.preventDefault();
        this.elements.fileUploadArea.classList.add('dragover');
    }
    
    handleDragLeave(e) {
        e.preventDefault();
        this.elements.fileUploadArea.classList.remove('dragover');
    }
    
    handleFileDrop(e) {
        e.preventDefault();
        this.elements.fileUploadArea.classList.remove('dragover');
        
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            this.handleFileSelection(files[0]);
        }
    }
    
    handleFileSelect(e) {
        const file = e.target.files[0];
        if (file) {
            this.handleFileSelection(file);
        }
    }
    
    handleFileSelection(file) {
        // Validate file type
        if (!file.type.startsWith('audio/')) {
            this.showStatus('Please select an audio file', 'error');
            return;
        }
        
        // Validate file size (max 50MB)
        if (file.size > 50 * 1024 * 1024) {
            this.showStatus('File size must be less than 50MB', 'error');
            return;
        }
        
        this.selectedFile = file;
        this.elements.fileName.textContent = file.name;
        this.elements.selectedFile.style.display = 'flex';
        this.elements.fileUploadArea.style.display = 'none';
        this.elements.processAudio.disabled = false;
        this.updateProcessButtonText();
        
        this.showStatus('File selected: ' + file.name, 'success');
    }
    
    removeSelectedFile() {
        this.selectedFile = null;
        this.elements.selectedFile.style.display = 'none';
        this.elements.fileUploadArea.style.display = 'block';
        this.elements.audioFileInput.value = '';
        
        if (!this.currentAudioBlob) {
            this.elements.processAudio.disabled = true;
        }
        this.updateProcessButtonText();
        
        this.showStatus('File removed', 'success');
    }
    
    updateProcessButtonText() {
        const hasRecording = this.currentAudioBlob !== null;
        const hasFile = this.selectedFile !== null;
        
        if (hasRecording && hasFile) {
            this.elements.processAudio.innerHTML = '<i class="fas fa-cogs"></i> Translate Recording';
        } else if (hasRecording) {
            this.elements.processAudio.innerHTML = '<i class="fas fa-cogs"></i> Translate Recording';
        } else if (hasFile) {
            this.elements.processAudio.innerHTML = '<i class="fas fa-cogs"></i> Translate File';
        } else {
            this.elements.processAudio.innerHTML = '<i class="fas fa-cogs"></i> Translate Audio';
        }
    }
    
    async processAudio() {
        const targetLanguage = this.elements.targetLanguage.value;
        let audioToProcess = null;
        
        // Determine which audio to process (recording takes priority)
        if (this.currentAudioBlob) {
            audioToProcess = this.currentAudioBlob;
        } else if (this.selectedFile) {
            audioToProcess = this.selectedFile;
        } else {
            this.showStatus('No audio to process', 'error');
            return;
        }
        
        this.showLoading(true);
        
        try {
            // Create FormData for the request
            const formData = new FormData();
            formData.append('audio_file', audioToProcess, 'audio.webm');
            formData.append('target_language', targetLanguage);
            formData.append('contentType', 'audio');
            
            // Send to n8n webhook
            const response = await fetch(this.n8nWebhookUrl, {
                method: 'POST',
                body: formData
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const result = await response.json();
            
            if (result.success) {
                this.displayResults(result);
                this.showStatus('Translation completed successfully', 'success');
            } else {
                throw new Error(result.message || 'Translation failed');
            }
            
        } catch (error) {
            console.error('Error processing audio:', error);
            this.showStatus('Failed to process audio: ' + error.message, 'error');
        } finally {
            this.showLoading(false);
        }
    }
    
    displayResults(result) {
        this.elements.originalText.value = result.original_text || '';
        this.elements.translatedText.value = result.translated_text || '';
        this.elements.detectedLanguage.textContent = result.detected_language || 'Unknown';
        this.elements.targetLanguageDisplay.textContent = result.target_language || 'Unknown';
        
        this.elements.resultsSection.style.display = 'block';
        this.elements.resultsSection.scrollIntoView({ behavior: 'smooth' });
    }
    
    updateTargetLanguageDisplay() {
        const selectedLanguage = this.elements.targetLanguage.value;
        this.elements.targetLanguageDisplay.textContent = selectedLanguage;
    }
    
    async copyToClipboard(text) {
        try {
            await navigator.clipboard.writeText(text);
            this.showStatus('Text copied to clipboard', 'success');
        } catch (error) {
            console.error('Failed to copy text:', error);
            this.showStatus('Failed to copy text', 'error');
        }
    }
    
    saveTranslation() {
        const originalText = this.elements.originalText.value;
        const translatedText = this.elements.translatedText.value;
        const detectedLanguage = this.elements.detectedLanguage.textContent;
        const targetLanguage = this.elements.targetLanguageDisplay.textContent;
        const timestamp = new Date().toLocaleString();
        
        const content = `Speech Translation Results
Generated: ${timestamp}

Original Language: ${detectedLanguage}
Target Language: ${targetLanguage}

Original Text:
${originalText}

Translated Text:
${translatedText}

---
Powered by Whisper AI and n8n
`;
        
        const blob = new Blob([content], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `translation_${timestamp.replace(/[/,:]/g, '-')}.txt`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        this.showStatus('Translation saved to file', 'success');
    }
    
    showLoading(show) {
        this.elements.loadingIndicator.style.display = show ? 'flex' : 'none';
    }
    
    showStatus(message, type = 'info') {
        const statusDiv = document.createElement('div');
        statusDiv.className = `status-message ${type}`;
        statusDiv.textContent = message;
        
        this.elements.statusMessages.appendChild(statusDiv);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (statusDiv.parentNode) {
                statusDiv.parentNode.removeChild(statusDiv);
            }
        }, 5000);
        
        // Also log to console
        console.log(`[${type.toUpperCase()}] ${message}`);
    }
}

// Initialize the app when the DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new SpeechTranslationApp();
});