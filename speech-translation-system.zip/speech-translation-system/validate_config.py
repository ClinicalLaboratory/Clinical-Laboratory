#!/usr/bin/env python3
"""
Configuration Validation Script
Validates that all components are correctly configured for Whisper service on port 8000
"""

import json
import yaml
import re
from pathlib import Path

def validate_docker_compose():
    """Validate Docker Compose configuration"""
    print("🐳 Validating Docker Compose configuration...")
    
    compose_file = Path("docker/docker-compose.yml")
    if not compose_file.exists():
        print("❌ docker-compose.yml not found")
        return False
    
    with open(compose_file, 'r') as f:
        content = f.read()
    
    # Check if Whisper API service is configured for port 8000
    if '"8000:8000"' in content or "'8000:8000'" in content:
        print("✅ Whisper API service correctly mapped to port 8000")
    else:
        print("❌ Whisper API service port mapping not found")
        return False
    
    # Check health check endpoint
    if "http://localhost:8000/health" in content:
        print("✅ Health check endpoint correctly configured")
    else:
        print("❌ Health check endpoint not properly configured")
        return False
    
    return True

def validate_n8n_workflow():
    """Validate n8n workflow configuration"""
    print("\n🔄 Validating n8n workflow configuration...")
    
    workflow_file = Path("n8n-workflows/speech-translation-workflow.json")
    if not workflow_file.exists():
        print("❌ n8n workflow file not found")
        return False
    
    with open(workflow_file, 'r') as f:
        workflow = json.load(f)
    
    # Check for correct Whisper API endpoints
    whisper_endpoints = []
    for node in workflow.get('nodes', []):
        if 'parameters' in node and 'url' in node['parameters']:
            url = node['parameters']['url']
            if 'whisper-api:8000' in url:
                whisper_endpoints.append(url)
    
    if len(whisper_endpoints) >= 2:
        print(f"✅ Found {len(whisper_endpoints)} Whisper API endpoints using port 8000")
        for endpoint in whisper_endpoints:
            print(f"   - {endpoint}")
    else:
        print("❌ Whisper API endpoints not properly configured")
        return False
    
    return True

def validate_whisper_service():
    """Validate Whisper service configuration"""
    print("\n🤖 Validating Whisper service configuration...")
    
    main_py = Path("docker/whisper/main.py")
    if not main_py.exists():
        print("❌ Whisper main.py not found")
        return False
    
    with open(main_py, 'r') as f:
        content = f.read()
    
    # Check if service is configured to run on port 8000
    if 'port=8000' in content:
        print("✅ Whisper service configured to run on port 8000")
    else:
        print("❌ Whisper service port not properly configured")
        return False
    
    # Check if health endpoint exists
    if '/health' in content:
        print("✅ Health endpoint defined in Whisper service")
    else:
        print("❌ Health endpoint not found in Whisper service")
        return False
    
    return True

def validate_dockerfile():
    """Validate Dockerfile configuration"""
    print("\n📦 Validating Dockerfile configuration...")
    
    dockerfile = Path("docker/whisper/Dockerfile")
    if not dockerfile.exists():
        print("❌ Dockerfile not found")
        return False
    
    with open(dockerfile, 'r') as f:
        content = f.read()
    
    # Check if port 8000 is exposed
    if 'EXPOSE 8000' in content:
        print("✅ Port 8000 properly exposed in Dockerfile")
    else:
        print("❌ Port 8000 not exposed in Dockerfile")
        return False
    
    # Check if health check uses port 8000
    if 'http://localhost:8000/health' in content:
        print("✅ Health check uses correct port in Dockerfile")
    else:
        print("❌ Health check port not properly configured in Dockerfile")
        return False
    
    return True

def validate_test_scripts():
    """Validate test scripts configuration"""
    print("\n🧪 Validating test scripts configuration...")
    
    test_files = [
        "test_system.py",
        "setup.py"
    ]
    
    all_valid = True
    for test_file in test_files:
        file_path = Path(test_file)
        if not file_path.exists():
            print(f"❌ {test_file} not found")
            all_valid = False
            continue
        
        with open(file_path, 'r') as f:
            content = f.read()
        
        if 'localhost:8000' in content:
            print(f"✅ {test_file} correctly references port 8000")
        else:
            print(f"❌ {test_file} does not reference port 8000")
            all_valid = False
    
    return all_valid

def validate_documentation():
    """Validate documentation references"""
    print("\n📚 Validating documentation...")
    
    doc_files = [
        "README.md",
        "docs/API.md",
        "docs/INSTALLATION.md",
        "docs/USER_GUIDE.md",
        "DEPLOYMENT_INSTRUCTIONS.md"
    ]
    
    all_valid = True
    for doc_file in doc_files:
        file_path = Path(doc_file)
        if not file_path.exists():
            print(f"⚠️  {doc_file} not found")
            continue
        
        with open(file_path, 'r') as f:
            content = f.read()
        
        if ':8000' in content:
            print(f"✅ {doc_file} references port 8000")
        else:
            print(f"⚠️  {doc_file} may not reference port 8000")
    
    return all_valid

def main():
    """Run all validation checks"""
    print("🔍 Whisper Service Port 8000 Configuration Validation")
    print("=" * 60)
    
    validations = [
        ("Docker Compose", validate_docker_compose),
        ("n8n Workflow", validate_n8n_workflow),
        ("Whisper Service", validate_whisper_service),
        ("Dockerfile", validate_dockerfile),
        ("Test Scripts", validate_test_scripts),
        ("Documentation", validate_documentation),
    ]
    
    results = {}
    for name, validator in validations:
        try:
            results[name] = validator()
        except Exception as e:
            print(f"❌ {name} validation failed with error: {e}")
            results[name] = False
    
    # Summary
    print("\n" + "=" * 60)
    print("📊 VALIDATION SUMMARY")
    print("=" * 60)
    
    passed = sum(1 for result in results.values() if result)
    total = len(results)
    
    for name, result in results.items():
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status} {name}")
    
    print(f"\nOverall: {passed}/{total} validations passed")
    
    if passed == total:
        print("\n🎉 All validations passed! Whisper service is correctly configured for port 8000.")
    else:
        print(f"\n⚠️  {total - passed} validation(s) failed. Please check the configuration.")
    
    return passed == total

if __name__ == "__main__":
    import sys
    success = main()
    sys.exit(0 if success else 1)