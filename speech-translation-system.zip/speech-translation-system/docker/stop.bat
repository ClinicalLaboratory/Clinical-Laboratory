@echo off
echo Stopping Speech Translation System...
echo.

REM Stop the services
docker-compose down

if %errorlevel% neq 0 (
    echo Error: Failed to stop services.
    echo Please check Docker Desktop.
    pause
    exit /b 1
)

echo.
echo Services stopped successfully!
echo.
echo To start the services again, run: start.bat
echo.
pause