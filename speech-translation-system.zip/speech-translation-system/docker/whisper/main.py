import os
import tempfile
import whisper
import torch
from fastapi import FastAPI, File, UploadFile, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
import librosa
import soundfile as sf
import numpy as np
from googletrans import Translator
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="Whisper Speech Translation API", version="1.0.0")

# Enable CORS for web interface
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global variables for models
whisper_model = None
translator = None

# Language mapping for better compatibility
LANGUAGE_CODES = {
    'english': 'en',
    'spanish': 'es',
    'french': 'fr',
    'german': 'de',
    'italian': 'it',
    'portuguese': 'pt',
    'russian': 'ru',
    'japanese': 'ja',
    'korean': 'ko',
    'chinese': 'zh',
    'arabic': 'ar',
    'hindi': 'hi',
    'dutch': 'nl',
    'swedish': 'sv',
    'norwegian': 'no',
    'danish': 'da',
    'finnish': 'fi',
    'polish': 'pl',
    'czech': 'cs',
    'hungarian': 'hu',
    'turkish': 'tr',
    'greek': 'el',
    'hebrew': 'he',
    'thai': 'th',
    'vietnamese': 'vi',
    'indonesian': 'id',
    'malay': 'ms',
    'filipino': 'tl',
    'ukrainian': 'uk',
    'bulgarian': 'bg',
    'croatian': 'hr',
    'serbian': 'sr',
    'slovenian': 'sl',
    'slovak': 'sk',
    'romanian': 'ro',
    'lithuanian': 'lt',
    'latvian': 'lv',
    'estonian': 'et'
}

class TranslationRequest(BaseModel):
    text: str
    target_language: str

class TranslationResponse(BaseModel):
    original_text: str
    translated_text: str
    detected_language: str
    target_language: str

@app.on_event("startup")
async def startup_event():
    """Initialize models on startup"""
    global whisper_model, translator
    
    try:
        logger.info("Loading Whisper model...")
        # Use base model for better performance on Surface devices
        whisper_model = whisper.load_model("base")
        logger.info("Whisper model loaded successfully")
        
        logger.info("Initializing translator...")
        translator = Translator()
        logger.info("Translator initialized successfully")
        
    except Exception as e:
        logger.error(f"Error during startup: {e}")
        raise e

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "whisper_loaded": whisper_model is not None,
        "translator_loaded": translator is not None
    }

@app.get("/languages")
async def get_supported_languages():
    """Get list of supported languages"""
    return {
        "languages": list(LANGUAGE_CODES.keys()),
        "language_codes": LANGUAGE_CODES
    }

def preprocess_audio(audio_data: np.ndarray, sample_rate: int) -> np.ndarray:
    """Preprocess audio for Whisper"""
    # Resample to 16kHz if needed
    if sample_rate != 16000:
        audio_data = librosa.resample(audio_data, orig_sr=sample_rate, target_sr=16000)
    
    # Normalize audio
    audio_data = audio_data.astype(np.float32)
    
    # Ensure mono
    if len(audio_data.shape) > 1:
        audio_data = np.mean(audio_data, axis=1)
    
    return audio_data

@app.post("/transcribe", response_model=dict)
async def transcribe_audio(
    audio_file: UploadFile = File(...),
    target_language: str = Form("english")
):
    """Transcribe and translate audio file"""
    if whisper_model is None or translator is None:
        raise HTTPException(status_code=503, detail="Models not loaded")
    
    try:
        # Read audio file
        audio_content = await audio_file.read()
        
        # Create temporary file
        with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as temp_file:
            temp_file.write(audio_content)
            temp_file_path = temp_file.name
        
        try:
            # Load and preprocess audio
            audio_data, sample_rate = librosa.load(temp_file_path, sr=None)
            processed_audio = preprocess_audio(audio_data, sample_rate)
            
            # Transcribe with Whisper
            logger.info("Transcribing audio...")
            result = whisper_model.transcribe(processed_audio)
            
            original_text = result["text"].strip()
            detected_language = result.get("language", "unknown")
            
            logger.info(f"Transcription: {original_text}")
            logger.info(f"Detected language: {detected_language}")
            
            # Translate if target language is different from detected language
            translated_text = original_text
            target_lang_code = LANGUAGE_CODES.get(target_language.lower(), target_language.lower())
            
            if detected_language != target_lang_code and original_text:
                try:
                    logger.info(f"Translating to {target_language}...")
                    translation = translator.translate(original_text, dest=target_lang_code)
                    translated_text = translation.text
                    logger.info(f"Translation: {translated_text}")
                except Exception as e:
                    logger.warning(f"Translation failed: {e}")
                    translated_text = original_text
            
            return {
                "success": True,
                "original_text": original_text,
                "translated_text": translated_text,
                "detected_language": detected_language,
                "target_language": target_language,
                "confidence": result.get("confidence", 0.0)
            }
            
        finally:
            # Clean up temporary file
            if os.path.exists(temp_file_path):
                os.unlink(temp_file_path)
                
    except Exception as e:
        logger.error(f"Error processing audio: {e}")
        raise HTTPException(status_code=500, detail=f"Error processing audio: {str(e)}")

@app.post("/translate", response_model=TranslationResponse)
async def translate_text(request: TranslationRequest):
    """Translate text to target language"""
    if translator is None:
        raise HTTPException(status_code=503, detail="Translator not loaded")
    
    try:
        target_lang_code = LANGUAGE_CODES.get(request.target_language.lower(), request.target_language.lower())
        
        # Detect source language
        detected = translator.detect(request.text)
        detected_language = detected.lang
        
        # Translate
        translation = translator.translate(request.text, dest=target_lang_code)
        
        return TranslationResponse(
            original_text=request.text,
            translated_text=translation.text,
            detected_language=detected_language,
            target_language=request.target_language
        )
        
    except Exception as e:
        logger.error(f"Error translating text: {e}")
        raise HTTPException(status_code=500, detail=f"Error translating text: {str(e)}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)