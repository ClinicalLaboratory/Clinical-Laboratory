@echo off
echo Starting Speech Translation System...
echo.

REM Check if Docker Desktop is running
docker info >nul 2>&1
if %errorlevel% neq 0 (
    echo Error: Docker Desktop is not running.
    echo Please start Docker Desktop and try again.
    pause
    exit /b 1
)

echo Docker Desktop is running.
echo.

REM Start the services
echo Starting services with Docker Compose...
docker-compose up -d

if %errorlevel% neq 0 (
    echo Error: Failed to start services.
    echo Please check Docker Desktop and try again.
    pause
    exit /b 1
)

echo.
echo Services started successfully!
echo.
echo Waiting for services to be ready...
timeout /t 10 /nobreak >nul

REM Check service health
echo Checking service health...
curl -s http://localhost:5678/healthz >nul 2>&1
if %errorlevel% neq 0 (
    echo Warning: n8n service may not be ready yet.
    echo Please wait a moment and check http://localhost:5678
) else (
    echo n8n service is ready at http://localhost:5678
)

curl -s http://localhost:8000/health >nul 2>&1
if %errorlevel% neq 0 (
    echo Warning: Whisper API service (port 8000) may not be ready yet.
    echo Please wait a moment for the service to initialize.
) else (
    echo Whisper API service is ready at http://localhost:8000
)

echo.
echo ========================================
echo  Speech Translation System Started
echo ========================================
echo.
echo n8n Interface: http://localhost:5678
echo Whisper API: http://localhost:8000
echo Web Interface: Open webapp\index.html in your browser
echo.
echo To stop the services, run: docker-compose down
echo.
pause