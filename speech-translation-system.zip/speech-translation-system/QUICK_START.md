# Quick Start Guide

Get your Real-time Speech Translation System running in 5 minutes!

## Prerequisites Check

✅ **Docker Desktop**: Installed and running  
✅ **Microsoft Surface**: Windows 10/11  
✅ **Web Browser**: Chrome, Edge, or Firefox  
✅ **Microphone**: Built-in or external  

## 1. Start the System

### Option A: Using Batch Files (Recommended for Windows)
```cmd
# Navigate to the docker directory
cd speech-translation-system\docker

# Start all services
start.bat
```

### Option B: Using Docker Compose
```cmd
cd speech-translation-system\docker
docker-compose up -d
```

## 2. Import n8n Workflow

1. Open: http://localhost:5678
2. Click "Import from file"
3. Select: `n8n-workflows/speech-translation-workflow.json`
4. Activate the workflow (toggle switch)

## 3. Open Web Interface

1. Navigate to: `webapp/index.html`
2. Open in your web browser
3. Allow microphone permissions

## 4. Test Translation

### Quick Test:
1. Select "Spanish" as target language
2. Click "Start Recording"
3. Say: "Hello, how are you today?"
4. Click "Stop Recording"
5. Click "Translate Audio"
6. See Spanish translation appear!

## 5. Stop the System

```cmd
# In the docker directory
stop.bat
```

## Troubleshooting

**Services won't start?**
- Ensure Docker Desktop is running
- Check ports 5678 and 8000 are free
- Try: `docker-compose down` then `docker-compose up -d`

**Microphone not working?**
- Check browser permissions
- Verify Windows microphone privacy settings
- Try refreshing the webpage

**Translation not working?**
- Verify n8n workflow is activated
- Check service health at http://localhost:8000/health
- Review logs: `docker-compose logs`

## What's Next?

- Read the [User Guide](docs/USER_GUIDE.md) for detailed usage
- Check the [API Documentation](docs/API.md) for integration
- Review [Installation Guide](docs/INSTALLATION.md) for advanced setup

## Need Help?

1. Check service status: `docker-compose ps`
2. View logs: `docker-compose logs -f`
3. Restart services: `docker-compose restart`
4. Full reset: `docker-compose down && docker-compose up -d`

**Enjoy your local, private speech translation system! 🎉**