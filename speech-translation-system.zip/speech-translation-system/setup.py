#!/usr/bin/env python3
"""
Speech Translation System Setup Script
Automates the complete setup process for Microsoft Surface devices
"""

import os
import sys
import subprocess
import time
import requests
import json
from pathlib import Path

class SetupManager:
    def __init__(self):
        self.project_root = Path(__file__).parent
        self.docker_dir = self.project_root / "docker"
        self.webapp_dir = self.project_root / "webapp"
        self.workflow_file = self.project_root / "n8n-workflows" / "speech-translation-workflow.json"
        
    def print_header(self, title):
        """Print a formatted header"""
        print("\n" + "=" * 60)
        print(f"🚀 {title}")
        print("=" * 60)
    
    def print_step(self, step, description):
        """Print a formatted step"""
        print(f"\n📋 Step {step}: {description}")
        print("-" * 40)
    
    def check_prerequisites(self):
        """Check if all prerequisites are installed"""
        self.print_step(1, "Checking Prerequisites")
        
        # Check Docker
        try:
            result = subprocess.run(["docker", "--version"], capture_output=True, text=True)
            if result.returncode == 0:
                print(f"✅ Docker: {result.stdout.strip()}")
            else:
                print("❌ Docker not found")
                return False
        except FileNotFoundError:
            print("❌ Docker not found. Please install Docker Desktop.")
            return False
        
        # Check Docker Compose
        try:
            result = subprocess.run(["docker-compose", "--version"], capture_output=True, text=True)
            if result.returncode == 0:
                print(f"✅ Docker Compose: {result.stdout.strip()}")
            else:
                print("❌ Docker Compose not found")
                return False
        except FileNotFoundError:
            print("❌ Docker Compose not found. Please install Docker Desktop.")
            return False
        
        # Check if Docker is running
        try:
            result = subprocess.run(["docker", "info"], capture_output=True, text=True)
            if result.returncode == 0:
                print("✅ Docker Desktop is running")
            else:
                print("❌ Docker Desktop is not running. Please start Docker Desktop.")
                return False
        except Exception:
            print("❌ Cannot connect to Docker. Please ensure Docker Desktop is running.")
            return False
        
        # Check available ports
        ports_to_check = [5678, 8000]
        for port in ports_to_check:
            if self.is_port_in_use(port):
                print(f"⚠️  Port {port} is in use. This may cause conflicts.")
            else:
                print(f"✅ Port {port} is available")
        
        print("\n✅ All prerequisites check passed!")
        return True
    
    def is_port_in_use(self, port):
        """Check if a port is in use"""
        import socket
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            return s.connect_ex(('localhost', port)) == 0
    
    def build_and_start_services(self):
        """Build and start Docker services"""
        self.print_step(2, "Building and Starting Services")
        
        print("🔨 Building Docker images (this may take 10-15 minutes on first run)...")
        
        try:
            # Change to docker directory
            os.chdir(self.docker_dir)
            
            # Build and start services
            result = subprocess.run(
                ["docker-compose", "up", "-d", "--build"],
                capture_output=True,
                text=True
            )
            
            if result.returncode == 0:
                print("✅ Services built and started successfully!")
                print(result.stdout)
            else:
                print("❌ Failed to start services:")
                print(result.stderr)
                return False
                
        except Exception as e:
            print(f"❌ Error starting services: {e}")
            return False
        finally:
            # Return to project root
            os.chdir(self.project_root)
        
        return True
    
    def wait_for_services(self):
        """Wait for services to be ready"""
        self.print_step(3, "Waiting for Services to Initialize")
        
        services = [
            ("n8n", "http://localhost:5678/healthz"),
            ("Whisper API (Docker Port 8000)", "http://localhost:8000/health")
        ]
        
        max_wait = 300  # 5 minutes
        start_time = time.time()
        
        for service_name, url in services:
            print(f"⏳ Waiting for {service_name}...")
            
            while time.time() - start_time < max_wait:
                try:
                    response = requests.get(url, timeout=5)
                    if response.status_code == 200:
                        print(f"✅ {service_name} is ready!")
                        break
                except requests.exceptions.RequestException:
                    pass
                
                time.sleep(5)
                print(".", end="", flush=True)
            else:
                print(f"\n⚠️  {service_name} may not be ready yet. Continuing anyway...")
        
        print("\n✅ Service initialization complete!")
        return True
    
    def setup_n8n_workflow(self):
        """Setup n8n workflow"""
        self.print_step(4, "Setting up n8n Workflow")
        
        print("📋 n8n workflow setup instructions:")
        print("1. Open http://localhost:5678 in your browser")
        print("2. Click 'Import from file' or use the '+' button")
        print(f"3. Import the file: {self.workflow_file}")
        print("4. Activate the workflow by clicking the toggle switch")
        print("5. Verify the webhook URL shows: http://localhost:5678/webhook/speech-translate")
        
        # Wait for user confirmation
        input("\nPress Enter after you have imported and activated the workflow...")
        
        # Test the webhook
        print("🧪 Testing n8n webhook...")
        try:
            response = requests.post(
                "http://localhost:5678/webhook/speech-translate",
                data={"text": "test", "target_language": "spanish", "contentType": "text"},
                timeout=10
            )
            if response.status_code == 200:
                print("✅ n8n webhook is working!")
            else:
                print(f"⚠️  n8n webhook test failed (status: {response.status_code})")
                print("Please verify the workflow is imported and activated.")
        except Exception as e:
            print(f"⚠️  n8n webhook test failed: {e}")
            print("Please verify the workflow is imported and activated.")
        
        return True
    
    def setup_web_interface(self):
        """Setup web interface"""
        self.print_step(5, "Setting up Web Interface")
        
        webapp_path = self.webapp_dir / "index.html"
        
        print(f"🌐 Web interface is ready at: {webapp_path.absolute()}")
        print("\nTo use the web interface:")
        print("1. Open the file in your web browser (Chrome, Edge, or Firefox)")
        print("2. Allow microphone permissions when prompted")
        print("3. Select your target language")
        print("4. Start recording or upload an audio file")
        print("5. Click 'Translate Audio' to process")
        
        # Ask if user wants to open the web interface
        try:
            open_browser = input("\nWould you like to open the web interface now? (y/n): ").lower().strip()
            if open_browser in ['y', 'yes']:
                self.open_web_interface()
        except KeyboardInterrupt:
            print("\nSkipping browser opening.")
        
        return True
    
    def open_web_interface(self):
        """Open web interface in default browser"""
        import webbrowser
        webapp_path = self.webapp_dir / "index.html"
        
        try:
            webbrowser.open(f"file://{webapp_path.absolute()}")
            print("✅ Web interface opened in your default browser!")
        except Exception as e:
            print(f"⚠️  Could not open browser automatically: {e}")
            print(f"Please manually open: {webapp_path.absolute()}")
    
    def run_system_test(self):
        """Run system integration test"""
        self.print_step(6, "Running System Test")
        
        print("🧪 Running comprehensive system test...")
        
        try:
            # Import and run the test
            sys.path.insert(0, str(self.project_root))
            from test_system import run_comprehensive_test
            
            success = run_comprehensive_test()
            if success:
                print("\n🎉 System test passed! Everything is working correctly.")
            else:
                print("\n⚠️  Some tests failed. Please check the output above.")
            
            return success
        except ImportError:
            print("⚠️  Test script not found. Skipping system test.")
            return True
        except Exception as e:
            print(f"⚠️  Test failed with error: {e}")
            return False
    
    def create_desktop_shortcuts(self):
        """Create desktop shortcuts (Windows)"""
        if sys.platform != "win32":
            return True
        
        try:
            import winshell
            from win32com.client import Dispatch
            
            desktop = winshell.desktop()
            
            # Create shortcut for starting services
            start_script = self.docker_dir / "start.bat"
            shortcut_path = os.path.join(desktop, "Start Speech Translation.lnk")
            
            shell = Dispatch('WScript.Shell')
            shortcut = shell.CreateShortCut(shortcut_path)
            shortcut.Targetpath = str(start_script)
            shortcut.WorkingDirectory = str(self.docker_dir)
            shortcut.IconLocation = str(start_script)
            shortcut.save()
            
            print("✅ Desktop shortcut created: Start Speech Translation")
            
        except ImportError:
            print("⚠️  Could not create desktop shortcuts (winshell not available)")
        except Exception as e:
            print(f"⚠️  Could not create desktop shortcuts: {e}")
        
        return True
    
    def print_final_instructions(self):
        """Print final setup instructions"""
        self.print_header("Setup Complete! 🎉")
        
        print("Your Speech Translation System is ready to use!")
        print("\n🚀 Quick Start:")
        print("1. Services are running in the background")
        print("2. n8n interface: http://localhost:5678")
        print("3. Web interface: Open webapp/index.html in your browser")
        print("\n🎯 To use the system:")
        print("• Select target language")
        print("• Record audio or upload file")
        print("• Click 'Translate Audio'")
        print("• View results and save if needed")
        
        print("\n🛠️  Management Commands:")
        print("• Start services: docker/start.bat")
        print("• Stop services: docker/stop.bat")
        print("• View logs: cd docker && docker-compose logs")
        
        print("\n📚 Documentation:")
        print("• User Guide: docs/USER_GUIDE.md")
        print("• API Documentation: docs/API.md")
        print("• Installation Guide: docs/INSTALLATION.md")
        
        print("\n🔒 Privacy:")
        print("• All processing happens locally")
        print("• No data sent to cloud services")
        print("• Audio processed in memory only")
        
        print("\n💡 Tips:")
        print("• Keep Docker Desktop running when using the system")
        print("• Use high-quality audio for best results")
        print("• Speak clearly and minimize background noise")
        
        print("\n🆘 Need Help?")
        print("• Check docs/TROUBLESHOOTING.md")
        print("• Run test_system.py to diagnose issues")
        print("• Review Docker logs for errors")
    
    def run_setup(self):
        """Run the complete setup process"""
        self.print_header("Speech Translation System Setup")
        
        print("Welcome to the Speech Translation System setup!")
        print("This will configure everything you need for local speech translation.")
        print("\nOptimized for Microsoft Surface devices with Windows 10/11")
        
        try:
            # Step 1: Check prerequisites
            if not self.check_prerequisites():
                print("\n❌ Prerequisites check failed. Please resolve the issues above.")
                return False
            
            # Step 2: Build and start services
            if not self.build_and_start_services():
                print("\n❌ Failed to start services. Please check Docker Desktop.")
                return False
            
            # Step 3: Wait for services
            if not self.wait_for_services():
                print("\n⚠️  Services may not be fully ready. Continuing anyway...")
            
            # Step 4: Setup n8n workflow
            if not self.setup_n8n_workflow():
                print("\n⚠️  n8n workflow setup incomplete. You can do this manually later.")
            
            # Step 5: Setup web interface
            if not self.setup_web_interface():
                print("\n⚠️  Web interface setup incomplete.")
            
            # Step 6: Run system test
            if not self.run_system_test():
                print("\n⚠️  System test had issues. The system may still work.")
            
            # Step 7: Create shortcuts (optional)
            self.create_desktop_shortcuts()
            
            # Final instructions
            self.print_final_instructions()
            
            return True
            
        except KeyboardInterrupt:
            print("\n\n⚠️  Setup interrupted by user.")
            print("You can run this script again to complete the setup.")
            return False
        except Exception as e:
            print(f"\n❌ Setup failed with error: {e}")
            return False

def main():
    """Main entry point"""
    setup_manager = SetupManager()
    success = setup_manager.run_setup()
    
    if success:
        print("\n🎉 Setup completed successfully!")
        sys.exit(0)
    else:
        print("\n❌ Setup failed. Please check the errors above.")
        sys.exit(1)

if __name__ == "__main__":
    main()