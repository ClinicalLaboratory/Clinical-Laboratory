# Real-time Speech Translation System

A complete end-to-end speech translation system using Whisper AI, n8n workflows, and a modern web interface. This system runs entirely locally without any cloud services, making it perfect for privacy-conscious users and offline environments.

## 🌟 Features

- **Real-time Speech Recognition**: Uses OpenAI's Whisper model for accurate speech-to-text conversion
- **Automatic Language Detection**: Automatically detects the source language of the audio
- **Multi-language Translation**: Supports translation to 35+ languages
- **Audio Recording**: Record audio directly from your microphone
- **File Upload**: Upload existing audio files in various formats
- **Modern Web Interface**: Beautiful, responsive web UI with drag-and-drop support
- **Local Processing**: Everything runs locally - no cloud services required
- **Privacy-First**: Your audio never leaves your device
- **Microsoft Surface Compatible**: Optimized for Surface hardware and Windows

## 🏗️ Architecture

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Web Interface │───▶│   n8n Workflow  │───▶│   Whisper API   │
│   (Frontend)    │    │   (Orchestrator)│    │   (AI Service)  │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

- **Web Interface**: Modern HTML5/CSS3/JavaScript frontend with audio recording capabilities
- **n8n Workflow**: Orchestrates the translation pipeline and handles API routing
- **Whisper API**: FastAPI service running Whisper AI model for speech recognition and translation

## 📋 Prerequisites

- **Docker Desktop**: Installed and running
- **Microsoft Surface**: Windows 10/11 with microphone access
- **Web Browser**: Chrome, Edge, or Firefox (with microphone permissions)
- **System Requirements**: 
  - 8GB+ RAM (recommended)
  - 4GB+ free disk space
  - Internet connection (for initial setup only)

## 🚀 Quick Start

### 1. Clone and Setup

```bash
# Navigate to the project directory
cd /workspace/speech-translation-system

# Make sure Docker Desktop is running
# Check Docker status
docker --version
docker-compose --version
```

### 2. Start the Services

```bash
# Start all services with Docker Compose
cd docker
docker-compose up -d

# Check if services are running (from docker directory)
cd docker
docker-compose ps
```

Expected output:
```
NAME                    COMMAND                  SERVICE             STATUS              PORTS
n8n-speech-translation  "tini -- /usr/local/…"   n8n                 running             0.0.0.0:5678->5678/tcp
whisper-api            "uvicorn main:app --…"   whisper-api         running             0.0.0.0:8000->8000/tcp
```

### 3. Import n8n Workflow

1. Open n8n interface: http://localhost:5678
2. Click "Import from file" or use the "+" button
3. Import the workflow file: `../n8n-workflows/speech-translation-workflow.json`
4. Activate the workflow by clicking the toggle switch

### 4. Open Web Interface

1. Navigate to the webapp directory: `../webapp/`
2. Open `index.html` in your web browser
3. Grant microphone permissions when prompted

## 📖 Detailed Setup Instructions

### Docker Services Configuration

The system uses two main Docker services:

#### n8n Service
- **Port**: 5678
- **Purpose**: Workflow orchestration and API routing
- **Health Check**: Available at http://localhost:5678/healthz

#### Whisper API Service
- **Port**: 8000 (Docker container exposed to localhost:8000)
- **Purpose**: Speech recognition and translation using Whisper AI
- **Internal Docker Network**: whisper-api:8000 (used by n8n workflow)
- **External Access**: http://localhost:8000 (for direct API calls)
- **Health Check**: Available at http://localhost:8000/health

### Service Health Checks

Before using the system, verify all services are healthy:

```bash
# Check n8n health
curl http://localhost:5678/healthz

# Check Whisper API health
curl http://localhost:8000/health

# Check available languages
curl http://localhost:8000/languages
```

### n8n Workflow Details

The workflow includes the following nodes:

1. **Webhook Trigger**: Receives audio data from the web interface
2. **Audio File Check**: Determines if the input is an audio file or text
3. **Whisper Transcribe**: Processes audio files for speech recognition
4. **Whisper Translate**: Translates text between languages
5. **Format Response**: Standardizes the API response
6. **Error Handling**: Manages errors and provides meaningful feedback

### Web Interface Features

#### Audio Recording
- Click "Start Recording" to begin capturing audio
- Real-time recording timer and status display
- "Stop Recording" to finish and prepare for processing
- "Play Recording" to preview your audio

#### File Upload
- Drag and drop audio files onto the upload area
- Click "Choose File" to browse for audio files
- Supported formats: WAV, MP3, M4A, FLAC, OGG, WEBM
- Maximum file size: 50MB

#### Language Selection
- Choose from 35+ supported languages
- Automatic source language detection
- Real-time target language updates

#### Results Display
- Original transcribed text
- Translated text in target language
- Detected source language information
- Copy to clipboard functionality
- Save translation to text file

## 🔧 Configuration

### Whisper Model Configuration

The system uses the Whisper "base" model by default for optimal performance on Surface devices. To change the model:

1. Edit `docker/whisper/main.py`
2. Modify line: `whisper_model = whisper.load_model("base")`
3. Available models: tiny, base, small, medium, large
4. Rebuild the Docker image: `cd docker && docker-compose build whisper-api`

### Language Support

Currently supported languages:
- English, Spanish, French, German, Italian, Portuguese
- Russian, Japanese, Korean, Chinese, Arabic, Hindi
- Dutch, Swedish, Norwegian, Danish, Finnish, Polish
- Czech, Hungarian, Turkish, Greek, Hebrew, Thai
- Vietnamese, Indonesian, Malay, Filipino, Ukrainian
- Bulgarian, Croatian, Serbian, Slovenian, Slovak
- Romanian, Lithuanian, Latvian, Estonian

### Performance Tuning

For better performance on Microsoft Surface:

1. **CPU Optimization**: The Whisper service is configured to use CPU inference for compatibility
2. **Memory Management**: Audio processing is done in-memory without temporary files
3. **Model Size**: Base model provides good accuracy with reasonable speed
4. **Audio Preprocessing**: Automatic resampling and normalization for optimal results

## 🧪 Testing the System

### End-to-End Test

1. **Start Services**: Ensure all Docker containers are running
2. **Open Web Interface**: Navigate to the webapp in your browser
3. **Test Recording**: 
   - Click "Start Recording"
   - Say "Hello, how are you today?" in English
   - Click "Stop Recording"
   - Select "Spanish" as target language
   - Click "Translate Audio"
4. **Verify Results**: Should show Spanish translation
5. **Test File Upload**:
   - Upload a sample audio file
   - Process and verify translation

### Troubleshooting

#### Common Issues

**Services won't start:**
```bash
# Check Docker Desktop is running
docker info

# Check port availability
netstat -an | findstr :5678
netstat -an | findstr :8000

# Restart services
docker-compose down
docker-compose up -d
```

**Microphone not working:**
- Check browser permissions for microphone access
- Ensure Windows microphone privacy settings allow browser access
- Try refreshing the webpage and re-granting permissions

**Translation not working:**
- Verify n8n workflow is activated
- Check webhook URL in the web interface matches n8n
- Review Docker logs: `cd docker && docker-compose logs whisper-api`

**Poor audio quality:**
- Ensure microphone is close to your mouth
- Minimize background noise
- Check Windows audio input levels

#### Log Analysis

```bash
# View n8n logs (from docker directory)
cd docker
docker-compose logs n8n

# View Whisper API logs
docker-compose logs whisper-api

# Follow logs in real-time
docker-compose logs -f
```

## 🔒 Security Considerations

- All processing happens locally - no data sent to external services
- Audio files are processed in memory and not stored permanently
- Web interface uses HTTPS-ready CORS configuration
- No authentication required for local use
- Temporary files are automatically cleaned up

## 🚀 Advanced Usage

### Custom Whisper Models

To use a different Whisper model:

1. Edit `docker/whisper/main.py`
2. Change the model name in the startup function
3. Rebuild: `cd docker && docker-compose build whisper-api`
4. Restart: `docker-compose up -d`

### API Integration

The system exposes REST APIs for integration:

#### n8n Webhook
```bash
POST http://localhost:5678/webhook/speech-translate
Content-Type: multipart/form-data

# Form data:
# audio_file: <audio file>
# target_language: <language name>
```

#### Direct Whisper API
```bash
POST http://localhost:8000/transcribe
Content-Type: multipart/form-data

# Form data:
# audio_file: <audio file>
# target_language: <language name>
```

### Batch Processing

For processing multiple files, you can use the API directly:

```python
import requests

def process_audio_file(file_path, target_language):
    with open(file_path, 'rb') as f:
        files = {'audio_file': f}
        data = {'target_language': target_language}
        response = requests.post(
            'http://localhost:5678/webhook/speech-translate',
            files=files,
            data=data
        )
    return response.json()
```

## 📊 Performance Metrics

### Expected Performance on Microsoft Surface

- **Model Loading**: 30-60 seconds (first time)
- **Audio Processing**: 2-5 seconds per minute of audio
- **Translation**: 1-2 seconds for typical sentences
- **Memory Usage**: 2-4GB during processing
- **Disk Space**: 3GB for base model + containers

### Optimization Tips

1. **Keep services running**: Avoid frequent restarts to prevent model reloading
2. **Use shorter audio clips**: Process in chunks for faster results
3. **Close unnecessary applications**: Free up system resources
4. **Use wired internet**: For initial Docker image downloads

## 🤝 Contributing

This system is designed to be extensible. Areas for contribution:

- Additional language support
- UI/UX improvements
- Performance optimizations
- Mobile device compatibility
- Additional audio format support

## 📄 License

This project is open source and available under the MIT License.

## 🆘 Support

For issues and questions:

1. Check the troubleshooting section above
2. Review Docker container logs
3. Verify all prerequisites are met
4. Test with simple audio samples first

## 🔄 Updates and Maintenance

### Updating the System

```bash
# Pull latest images (from docker directory)
cd docker
docker-compose pull

# Restart services
docker-compose down
docker-compose up -d
```

### Backup and Restore

```bash
# Backup n8n data (from docker directory)
cd docker
docker-compose exec n8n tar -czf /tmp/n8n-backup.tar.gz /home/node/.n8n

# Copy backup to host
docker cp n8n-speech-translation:/tmp/n8n-backup.tar.gz ./n8n-backup.tar.gz
```

---

**Built with ❤️ for Microsoft Surface users who value privacy and local processing.**