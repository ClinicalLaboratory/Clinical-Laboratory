# User Guide

This guide explains how to use the Real-time Speech Translation System effectively on your Microsoft Surface device.

## Getting Started

### Starting the System

1. **Start Docker Desktop**: Ensure Docker Desktop is running
2. **Start Services**: 
   ```cmd
   cd speech-translation-system\docker
   docker-compose up -d
   ```
3. **Open Web Interface**: Navigate to `webapp\index.html` in your browser
4. **Verify n8n**: Check http://localhost:5678 is accessible

### System Status Check

Before using the system, verify all components are working:

1. **Green indicators** should appear for all services
2. **Microphone permission** should be granted
3. **Language list** should be populated

## Using the Web Interface

### Language Selection

1. **Choose Target Language**: Select from the dropdown menu
   - 35+ languages supported
   - Language selection affects translation output
   - Source language is automatically detected

2. **Supported Languages Include**:
   - European: English, Spanish, French, German, Italian, Portuguese, Dutch, Swedish, Norwegian, Danish, Finnish, Polish, Czech, Hungarian, Turkish, Greek
   - Asian: Japanese, Korean, Chinese, Arabic, Hindi, Thai, Vietnamese, Indonesian, Malay, Filipino
   - Slavic: Russian, Ukrainian, Bulgarian, Croatian, Serbian, Slovenian, Slovak
   - Baltic: Lithuanian, Latvian, Estonian
   - Semitic: Hebrew, Arabic

### Audio Recording

#### Starting a Recording

1. **Click "Start Recording"**
   - Microphone icon will turn red
   - Timer will begin counting
   - Status shows "Recording..."

2. **Speak Clearly**:
   - Hold Surface 12-18 inches from your mouth
   - Speak at normal volume and pace
   - Minimize background noise
   - Pause briefly between sentences

3. **Monitor Recording**:
   - Timer shows elapsed time
   - Status indicator confirms recording is active
   - No time limit, but shorter clips process faster

#### Stopping a Recording

1. **Click "Stop Recording"**
   - Recording stops immediately
   - Audio is prepared for processing
   - Play button becomes available

2. **Preview Your Recording** (Optional):
   - Click "Play Recording" to review
   - Ensure audio quality is good
   - Re-record if needed

#### Recording Tips

- **Optimal Environment**: Quiet room with minimal echo
- **Clear Speech**: Speak naturally, not too fast or slow
- **Surface Position**: Keep microphone unobstructed
- **Background Noise**: Turn off fans, music, TV
- **Multiple Languages**: Record one language at a time for best results

### File Upload

#### Supported File Formats

- **Audio Formats**: WAV, MP3, M4A, FLAC, OGG, WEBM
- **Maximum Size**: 50MB per file
- **Quality**: Higher quality audio = better transcription
- **Length**: No strict limit, but shorter files process faster

#### Upload Methods

**Method 1: Drag and Drop**
1. Drag audio file from File Explorer
2. Drop onto the upload area
3. File name appears when selected
4. "Translate File" button becomes active

**Method 2: File Browser**
1. Click "Choose File" button
2. Browse to your audio file
3. Select and click "Open"
4. File is ready for processing

#### File Management

- **Remove File**: Click the "X" button to remove selected file
- **Replace File**: Simply select a new file to replace the current one
- **File Info**: File name and size are displayed

### Processing Audio

#### Translation Process

1. **Select Target Language**: Choose from dropdown
2. **Prepare Audio**: Either record or upload file
3. **Click "Translate Audio"**: Processing begins
4. **Wait for Results**: Processing indicator shows progress
5. **Review Results**: Translation appears in results section

#### Processing Time

- **Recording**: 2-5 seconds per minute of audio
- **File Upload**: 3-7 seconds per minute of audio
- **First Use**: Additional 30-60 seconds for model loading
- **Subsequent Uses**: Faster due to cached models

#### What Happens During Processing

1. **Audio Analysis**: Whisper analyzes audio characteristics
2. **Language Detection**: Automatically identifies source language
3. **Speech Recognition**: Converts speech to text
4. **Translation**: Translates text to target language
5. **Response Formatting**: Prepares results for display

### Understanding Results

#### Results Display

**Original Text Section**:
- Shows transcribed text from your audio
- Displays detected source language
- Editable text area for corrections

**Translated Text Section**:
- Shows translation in target language
- Displays target language confirmation
- Editable text area for modifications

**Language Information**:
- **Detected**: Shows automatically identified source language
- **Target**: Confirms your selected target language
- **Confidence**: Internal processing confidence (when available)

#### Result Actions

**Copy to Clipboard**:
- "Copy Original": Copies source text
- "Copy Translation": Copies translated text
- Useful for pasting into other applications

**Save Translation**:
- Creates a text file with complete results
- Includes timestamp and language information
- Downloads automatically to your Downloads folder

### Advanced Features

#### Batch Processing

For multiple files:
1. Process files one at a time
2. Save each translation
3. Combine results as needed

#### Text Editing

- **Edit Original**: Correct transcription errors
- **Edit Translation**: Modify translation if needed
- **Re-translate**: Process edited text through translation API

#### Quality Optimization

**For Better Transcription**:
- Use high-quality audio files
- Ensure clear speech without mumbling
- Minimize background noise
- Use proper microphone technique

**For Better Translation**:
- Ensure accurate transcription first
- Use complete sentences when possible
- Avoid heavy accents or dialects
- Consider context and idioms

## Best Practices

### Audio Recording Best Practices

1. **Environment Setup**:
   - Choose quiet location
   - Close windows and doors
   - Turn off air conditioning/fans
   - Use soft furnishings to reduce echo

2. **Microphone Technique**:
   - Maintain consistent distance (12-18 inches)
   - Speak directly toward Surface microphone
   - Avoid covering microphone with hands
   - Keep Surface on stable surface

3. **Speech Technique**:
   - Speak at normal conversational pace
   - Enunciate clearly without over-articulating
   - Pause between sentences
   - Avoid filler words (um, uh, like)

### File Upload Best Practices

1. **File Quality**:
   - Use uncompressed formats when possible (WAV, FLAC)
   - Minimum 16kHz sample rate
   - Mono or stereo both supported
   - Avoid heavily compressed MP3 files

2. **File Preparation**:
   - Edit out long silences
   - Normalize audio levels
   - Remove background music
   - Split very long recordings

### Translation Best Practices

1. **Language Selection**:
   - Choose target language before processing
   - Consider regional variations (e.g., Spanish vs. Mexican Spanish)
   - Be aware of language limitations

2. **Content Considerations**:
   - Technical terms may not translate well
   - Idioms and colloquialisms may be literal
   - Names and proper nouns may be transcribed phonetically
   - Numbers and dates follow target language conventions

## Troubleshooting Common Issues

### Audio Issues

**Problem**: Microphone not working
- **Solution**: Check browser permissions, Windows privacy settings
- **Check**: Microphone icon in browser address bar
- **Test**: Try recording in another application

**Problem**: Poor audio quality
- **Solution**: Check microphone settings, reduce background noise
- **Check**: Windows sound settings, microphone levels
- **Test**: Record a test clip and listen back

**Problem**: No audio detected
- **Solution**: Ensure microphone is not muted, check input levels
- **Check**: Windows sound control panel
- **Test**: Speak louder or move closer to microphone

### Translation Issues

**Problem**: Inaccurate transcription
- **Solution**: Speak more clearly, reduce background noise
- **Check**: Audio quality, speaking pace
- **Test**: Try with simpler sentences first

**Problem**: Poor translation quality
- **Solution**: Ensure accurate transcription first
- **Check**: Source language detection is correct
- **Test**: Try translating individual sentences

**Problem**: Processing takes too long
- **Solution**: Use shorter audio clips, check system resources
- **Check**: Docker Desktop resource allocation
- **Test**: Close other applications to free up memory

### Technical Issues

**Problem**: Web interface not loading
- **Solution**: Check if services are running, restart Docker
- **Check**: http://localhost:5678 accessibility
- **Test**: Try different browser

**Problem**: Connection errors
- **Solution**: Verify firewall settings, restart services
- **Check**: Windows Defender Firewall exceptions
- **Test**: Access services directly via URLs

## Performance Tips

### System Optimization

1. **Close Unnecessary Applications**: Free up RAM and CPU
2. **Use Power Adapter**: Ensure consistent performance
3. **Keep Surface Cool**: Avoid thermal throttling
4. **Update Windows**: Ensure latest drivers and updates

### Usage Optimization

1. **Process Shorter Clips**: 30-60 seconds for fastest results
2. **Use High-Quality Audio**: Better input = better output
3. **Choose Appropriate Languages**: Some language pairs work better
4. **Monitor System Resources**: Check Task Manager during processing

## Integration Options

### Using with Other Applications

1. **Copy/Paste**: Use clipboard functions to transfer text
2. **File Export**: Save translations as text files
3. **API Access**: Direct API calls for custom integration

### Automation Possibilities

1. **Batch Scripts**: Process multiple files automatically
2. **Scheduled Processing**: Set up automated translation tasks
3. **Custom Workflows**: Integrate with other n8n workflows

## Privacy and Security

### Data Handling

- **Local Processing**: All audio stays on your device
- **No Cloud Services**: No data sent to external servers
- **Temporary Storage**: Audio processed in memory only
- **Automatic Cleanup**: Temporary files removed after processing

### Security Features

- **Local Network Only**: Services bound to localhost
- **No Authentication Required**: For local use only
- **CORS Enabled**: For web interface integration
- **Firewall Friendly**: Standard HTTP ports only

## Getting Help

### Self-Help Resources

1. **Check Service Status**: Verify all containers are running
2. **Review Logs**: Check Docker logs for errors
3. **Test Components**: Verify each service individually
4. **Restart Services**: Often resolves temporary issues

### Common Solutions

1. **Restart Docker Desktop**: Resolves most service issues
2. **Clear Browser Cache**: Fixes web interface problems
3. **Check Microphone Permissions**: Required for recording
4. **Verify Network Connectivity**: Needed for initial setup

Remember: The system is designed to work entirely offline after initial setup, ensuring your privacy and data security.