# API Documentation

This document describes the APIs available in the Real-time Speech Translation System for integration and automation purposes.

## Overview

The system exposes two main API endpoints:
1. **n8n Webhook API**: Main entry point for the web interface
2. **Whisper API**: Direct access to speech recognition and translation services

## n8n Webhook API

### Base URL
```
http://localhost:5678/webhook/speech-translate
```

### Authentication
No authentication required for local usage.

### Endpoints

#### POST /webhook/speech-translate

Processes audio files and returns translation results.

**Request Format:**
```http
POST /webhook/speech-translate
Content-Type: multipart/form-data

Form Data:
- audio_file: <binary audio data>
- target_language: <string> (optional, defaults to "english")
- contentType: "audio" (required)
```

**Response Format:**
```json
{
  "success": true,
  "original_text": "Hello, how are you?",
  "translated_text": "Hola, ¿cómo estás?",
  "detected_language": "en",
  "target_language": "spanish",
  "confidence": 0.95,
  "timestamp": "2025-01-02T12:00:00.000Z"
}
```

**Error Response:**
```json
{
  "error": "Processing failed",
  "message": "Detailed error message"
}
```

**Example Usage (cURL):**
```bash
curl -X POST \
  http://localhost:5678/webhook/speech-translate \
  -F "audio_file=@sample.wav" \
  -F "target_language=spanish" \
  -F "contentType=audio"
```

**Example Usage (Python):**
```python
import requests

def translate_audio(file_path, target_language="english"):
    url = "http://localhost:5678/webhook/speech-translate"
    
    with open(file_path, 'rb') as audio_file:
        files = {'audio_file': audio_file}
        data = {
            'target_language': target_language,
            'contentType': 'audio'
        }
        
        response = requests.post(url, files=files, data=data)
        return response.json()

# Usage
result = translate_audio("recording.wav", "spanish")
print(f"Translation: {result['translated_text']}")
```

**Example Usage (JavaScript):**
```javascript
async function translateAudio(audioFile, targetLanguage = 'english') {
    const formData = new FormData();
    formData.append('audio_file', audioFile);
    formData.append('target_language', targetLanguage);
    formData.append('contentType', 'audio');
    
    const response = await fetch('http://localhost:5678/webhook/speech-translate', {
        method: 'POST',
        body: formData
    });
    
    return await response.json();
}

// Usage with file input
const fileInput = document.getElementById('audioFile');
const result = await translateAudio(fileInput.files[0], 'spanish');
console.log('Translation:', result.translated_text);
```

## Whisper API

### Base URL
```
http://localhost:8000
```

### Authentication
No authentication required for local usage.

### Endpoints

#### GET /health

Health check endpoint to verify service status.

**Response:**
```json
{
  "status": "healthy",
  "whisper_loaded": true,
  "translator_loaded": true
}
```

#### GET /languages

Returns list of supported languages.

**Response:**
```json
{
  "languages": [
    "english", "spanish", "french", "german", "italian",
    "portuguese", "russian", "japanese", "korean", "chinese",
    "arabic", "hindi", "dutch", "swedish", "norwegian"
  ],
  "language_codes": {
    "english": "en",
    "spanish": "es",
    "french": "fr",
    "german": "de"
  }
}
```

#### POST /transcribe

Transcribes and translates audio files directly.

**Request Format:**
```http
POST /transcribe
Content-Type: multipart/form-data

Form Data:
- audio_file: <binary audio data>
- target_language: <string> (optional, defaults to "english")
```

**Response Format:**
```json
{
  "success": true,
  "original_text": "Hello, how are you?",
  "translated_text": "Hola, ¿cómo estás?",
  "detected_language": "en",
  "target_language": "spanish",
  "confidence": 0.95
}
```

**Example Usage:**
```bash
curl -X POST \
  http://localhost:8000/transcribe \
  -F "audio_file=@sample.wav" \
  -F "target_language=spanish"
```

#### POST /translate

Translates text between languages (no audio processing).

**Request Format:**
```http
POST /translate
Content-Type: application/json

{
  "text": "Hello, how are you?",
  "target_language": "spanish"
}
```

**Response Format:**
```json
{
  "original_text": "Hello, how are you?",
  "translated_text": "Hola, ¿cómo estás?",
  "detected_language": "en",
  "target_language": "spanish"
}
```

**Example Usage:**
```bash
curl -X POST \
  http://localhost:8000/translate \
  -H "Content-Type: application/json" \
  -d '{"text": "Hello, how are you?", "target_language": "spanish"}'
```

## Language Codes

### Supported Languages

| Language | Code | Language | Code |
|----------|------|----------|------|
| English | en | Japanese | ja |
| Spanish | es | Korean | ko |
| French | fr | Chinese | zh |
| German | de | Arabic | ar |
| Italian | it | Hindi | hi |
| Portuguese | pt | Dutch | nl |
| Russian | ru | Swedish | sv |
| Norwegian | no | Danish | da |
| Finnish | fi | Polish | pl |
| Czech | cs | Hungarian | hu |
| Turkish | tr | Greek | el |
| Hebrew | he | Thai | th |
| Vietnamese | vi | Indonesian | id |
| Malay | ms | Filipino | tl |
| Ukrainian | uk | Bulgarian | bg |
| Croatian | hr | Serbian | sr |
| Slovenian | sl | Slovak | sk |
| Romanian | ro | Lithuanian | lt |
| Latvian | lv | Estonian | et |

## Error Handling

### Common Error Codes

| HTTP Code | Description | Solution |
|-----------|-------------|----------|
| 400 | Bad Request | Check request format and parameters |
| 413 | File Too Large | Reduce file size (max 50MB) |
| 415 | Unsupported Media Type | Use supported audio formats |
| 500 | Internal Server Error | Check service logs, restart if needed |
| 503 | Service Unavailable | Wait for models to load, check health endpoint |

### Error Response Format

```json
{
  "error": "Error type",
  "message": "Detailed error description",
  "code": "ERROR_CODE"
}
```

### Handling Errors in Code

**Python Example:**
```python
import requests

def safe_translate_audio(file_path, target_language):
    try:
        response = requests.post(
            "http://localhost:5678/webhook/speech-translate",
            files={'audio_file': open(file_path, 'rb')},
            data={'target_language': target_language, 'contentType': 'audio'},
            timeout=60
        )
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        return {"error": str(e), "success": False}
    except Exception as e:
        return {"error": f"Unexpected error: {str(e)}", "success": False}
```

**JavaScript Example:**
```javascript
async function safeTranslateAudio(audioFile, targetLanguage) {
    try {
        const formData = new FormData();
        formData.append('audio_file', audioFile);
        formData.append('target_language', targetLanguage);
        formData.append('contentType', 'audio');
        
        const response = await fetch('http://localhost:5678/webhook/speech-translate', {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        return await response.json();
    } catch (error) {
        return { error: error.message, success: false };
    }
}
```

## Rate Limiting

### Current Limits
- No rate limiting implemented for local usage
- Processing time depends on audio length and system resources
- Concurrent requests are queued automatically

### Best Practices
- Process files sequentially for best performance
- Keep audio files under 5 minutes for optimal response times
- Monitor system resources during batch processing

## Integration Examples

### Batch Processing Script

```python
import os
import requests
import time
from pathlib import Path

def batch_translate_directory(directory_path, target_language="english"):
    """
    Translate all audio files in a directory
    """
    audio_extensions = ['.wav', '.mp3', '.m4a', '.flac', '.ogg']
    results = []
    
    for file_path in Path(directory_path).iterdir():
        if file_path.suffix.lower() in audio_extensions:
            print(f"Processing: {file_path.name}")
            
            result = translate_audio(str(file_path), target_language)
            if result.get('success'):
                # Save translation to text file
                output_file = file_path.with_suffix('.txt')
                with open(output_file, 'w', encoding='utf-8') as f:
                    f.write(f"Original: {result['original_text']}\n")
                    f.write(f"Translation: {result['translated_text']}\n")
                    f.write(f"Languages: {result['detected_language']} -> {result['target_language']}\n")
                
                results.append({
                    'file': file_path.name,
                    'success': True,
                    'translation': result['translated_text']
                })
            else:
                results.append({
                    'file': file_path.name,
                    'success': False,
                    'error': result.get('error', 'Unknown error')
                })
            
            # Small delay to prevent overwhelming the system
            time.sleep(1)
    
    return results

# Usage
results = batch_translate_directory("./audio_files", "spanish")
for result in results:
    if result['success']:
        print(f"✓ {result['file']}: {result['translation'][:50]}...")
    else:
        print(f"✗ {result['file']}: {result['error']}")
```

### Web Application Integration

```javascript
class TranslationService {
    constructor(baseUrl = 'http://localhost:5678') {
        this.baseUrl = baseUrl;
    }
    
    async translateAudio(audioBlob, targetLanguage = 'english') {
        const formData = new FormData();
        formData.append('audio_file', audioBlob, 'recording.webm');
        formData.append('target_language', targetLanguage);
        formData.append('contentType', 'audio');
        
        const response = await fetch(`${this.baseUrl}/webhook/speech-translate`, {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            throw new Error(`Translation failed: ${response.status}`);
        }
        
        return await response.json();
    }
    
    async getSupportedLanguages() {
        const response = await fetch('http://localhost:8000/languages');
        return await response.json();
    }
    
    async checkHealth() {
        try {
            const response = await fetch('http://localhost:8000/health');
            return await response.json();
        } catch (error) {
            return { status: 'unhealthy', error: error.message };
        }
    }
}

// Usage in web application
const translationService = new TranslationService();

// Check if services are available
const health = await translationService.checkHealth();
if (health.status === 'healthy') {
    // Get supported languages
    const languages = await translationService.getSupportedLanguages();
    
    // Translate audio
    const result = await translationService.translateAudio(audioBlob, 'spanish');
    console.log('Translation:', result.translated_text);
}
```

### Command Line Tool

```python
#!/usr/bin/env python3
"""
Command line tool for speech translation
Usage: python translate_cli.py input.wav --target spanish --output result.txt
"""

import argparse
import requests
import sys
from pathlib import Path

def main():
    parser = argparse.ArgumentParser(description='Translate speech from audio files')
    parser.add_argument('input', help='Input audio file')
    parser.add_argument('--target', default='english', help='Target language')
    parser.add_argument('--output', help='Output text file (optional)')
    parser.add_argument('--api-url', default='http://localhost:5678/webhook/speech-translate', 
                       help='API endpoint URL')
    
    args = parser.parse_args()
    
    # Check if input file exists
    input_path = Path(args.input)
    if not input_path.exists():
        print(f"Error: File {args.input} not found")
        sys.exit(1)
    
    # Translate audio
    try:
        with open(input_path, 'rb') as audio_file:
            files = {'audio_file': audio_file}
            data = {'target_language': args.target, 'contentType': 'audio'}
            
            print(f"Translating {input_path.name} to {args.target}...")
            response = requests.post(args.api_url, files=files, data=data)
            response.raise_for_status()
            
            result = response.json()
            
            if result.get('success'):
                print(f"Original ({result['detected_language']}): {result['original_text']}")
                print(f"Translation ({result['target_language']}): {result['translated_text']}")
                
                # Save to output file if specified
                if args.output:
                    with open(args.output, 'w', encoding='utf-8') as f:
                        f.write(f"Original: {result['original_text']}\n")
                        f.write(f"Translation: {result['translated_text']}\n")
                    print(f"Results saved to {args.output}")
            else:
                print(f"Error: {result.get('error', 'Translation failed')}")
                sys.exit(1)
                
    except requests.exceptions.RequestException as e:
        print(f"API Error: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()
```

## Performance Considerations

### Request Optimization
- Use appropriate audio formats (WAV, FLAC for quality; MP3, OGG for size)
- Keep file sizes reasonable (under 10MB recommended)
- Process shorter clips for faster response times

### System Resources
- Monitor CPU and memory usage during processing
- Allow adequate time for model loading on first request
- Consider system thermal limits on Surface devices

### Concurrent Processing
- System handles one request at a time for optimal performance
- Queue multiple requests rather than sending simultaneously
- Implement retry logic for failed requests

## Security Considerations

### Local Network Only
- APIs are bound to localhost (127.0.0.1)
- Not accessible from external networks by default
- No authentication required for local usage

### Data Privacy
- All processing happens locally
- No data sent to external services
- Audio files processed in memory only
- Automatic cleanup of temporary files

### Production Deployment
If deploying beyond localhost:
- Implement authentication (API keys, OAuth)
- Use HTTPS for encrypted communication
- Add rate limiting and request validation
- Configure proper firewall rules

## Monitoring and Logging

### Health Monitoring
```bash
# Check service health
curl http://localhost:8000/health
curl http://localhost:5678/healthz

# Monitor Docker containers
cd docker && docker-compose ps
cd docker && docker-compose logs -f
```

### Performance Monitoring
```python
import time
import requests

def monitor_api_performance():
    start_time = time.time()
    
    # Test health endpoint
    health_response = requests.get('http://localhost:8000/health')
    health_time = time.time() - start_time
    
    print(f"Health check: {health_time:.2f}s - {health_response.status_code}")
    
    # Test with small audio file
    start_time = time.time()
    # ... perform translation test
    translation_time = time.time() - start_time
    
    print(f"Translation test: {translation_time:.2f}s")

# Run monitoring
monitor_api_performance()
```

This API documentation provides comprehensive information for integrating with the speech translation system. For additional support or custom integration requirements, refer to the main documentation or system logs.