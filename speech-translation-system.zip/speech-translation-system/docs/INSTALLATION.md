# Installation Guide

This guide provides step-by-step instructions for setting up the Real-time Speech Translation System on Microsoft Surface devices.

## System Requirements

### Hardware Requirements
- **Microsoft Surface**: Any Surface device (Surface Pro, Surface Laptop, Surface Book, etc.)
- **RAM**: Minimum 8GB, Recommended 16GB
- **Storage**: 5GB free space for Docker images and models
- **Microphone**: Built-in or external microphone
- **Internet**: Required for initial setup and Docker image downloads

### Software Requirements
- **Operating System**: Windows 10 (version 1903+) or Windows 11
- **Docker Desktop**: Version 4.0 or later
- **Web Browser**: Chrome 88+, Edge 88+, or Firefox 85+
- **Git**: For cloning the repository (optional)

## Pre-Installation Steps

### 1. Install Docker Desktop

1. Download Docker Desktop from: https://www.docker.com/products/docker-desktop/
2. Run the installer as Administrator
3. Follow the installation wizard
4. Restart your Surface when prompted
5. Launch Docker Desktop and complete the initial setup
6. Verify installation:
   ```cmd
   docker --version
   docker-compose --version
   ```

### 2. Enable Windows Features

Ensure the following Windows features are enabled:
- Hyper-V (for Docker)
- Windows Subsystem for Linux (WSL2)
- Virtual Machine Platform

To enable these features:
1. Open "Turn Windows features on or off"
2. Check the required features
3. Restart your Surface

### 3. Configure Docker Settings

1. Open Docker Desktop
2. Go to Settings → General
3. Ensure "Use WSL 2 based engine" is checked
4. Go to Settings → Resources → Advanced
5. Allocate at least 4GB RAM to Docker
6. Apply & Restart

## Installation Steps

### Step 1: Download the Project

Option A: Download from GitHub (if available)
```cmd
git clone <repository-url>
cd speech-translation-system
```

Option B: Extract from provided files
```cmd
# Extract the project files to your desired location
# Navigate to the project directory
cd speech-translation-system
```

### Step 2: Verify Project Structure

Ensure your project directory contains:
```
speech-translation-system/
├── docker/
│   ├── docker-compose.yml
│   └── whisper/
│       ├── Dockerfile
│       ├── main.py
│       └── requirements.txt
├── n8n-workflows/
│   └── speech-translation-workflow.json
├── webapp/
│   ├── index.html
│   ├── styles.css
│   └── script.js
├── docs/
└── README.md
```

### Step 3: Build and Start Services

1. Open Command Prompt or PowerShell as Administrator
2. Navigate to the docker directory:
   ```cmd
   cd speech-translation-system\docker
   ```

3. Build and start the services:
   ```cmd
   docker-compose up -d --build
   ```

4. Wait for the build process to complete (this may take 10-15 minutes on first run)

5. Verify services are running:
   ```cmd
   docker-compose ps
   ```

Expected output:
```
NAME                    COMMAND                  SERVICE             STATUS              PORTS
n8n-speech-translation  "tini -- /usr/local/…"   n8n                 running             0.0.0.0:5678->5678/tcp
whisper-api            "uvicorn main:app --…"   whisper-api         running             0.0.0.0:8000->8000/tcp
```

### Step 4: Configure n8n Workflow

1. Open your web browser
2. Navigate to: http://localhost:5678
3. n8n will start with a welcome screen
4. Click "Import from file" or use the "+" button to create a new workflow
5. Import the workflow file: `../n8n-workflows/speech-translation-workflow.json`
6. The workflow should appear with connected nodes
7. Click the toggle switch to activate the workflow
8. Verify the webhook URL is: http://localhost:5678/webhook/speech-translate

### Step 5: Test the Web Interface

1. Navigate to the webapp directory: `../webapp/`
2. Open `index.html` in your web browser
3. When prompted, allow microphone access
4. The interface should load with all sections visible

## Verification Steps

### 1. Service Health Checks

Test each service individually:

```cmd
# Test n8n
curl http://localhost:5678/healthz

# Test Whisper API
curl http://localhost:8000/health

# Test available languages
curl http://localhost:8000/languages
```

### 2. End-to-End Test

1. Open the web interface
2. Select "Spanish" as target language
3. Click "Start Recording"
4. Say "Hello, how are you?" clearly
5. Click "Stop Recording"
6. Click "Translate Audio"
7. Verify you receive a Spanish translation

### 3. File Upload Test

1. Download a sample audio file (WAV or MP3)
2. Drag and drop it onto the upload area
3. Select a target language
4. Click "Translate File"
5. Verify the translation appears

## Troubleshooting Installation Issues

### Docker Issues

**Error: Docker daemon not running**
```cmd
# Solution: Start Docker Desktop
# Check Windows Services for Docker Desktop Service
```

**Error: Port already in use**
```cmd
# Check what's using the ports
netstat -an | findstr :5678
netstat -an | findstr :8000

# Stop conflicting services or change ports in docker-compose.yml
```

**Error: Not enough memory**
```cmd
# Increase Docker memory allocation in Docker Desktop settings
# Close unnecessary applications
```

### Build Issues

**Error: Failed to build whisper-api**
```cmd
# Check internet connection
# Clear Docker cache
docker system prune -a

# Rebuild
docker-compose build --no-cache
```

**Error: Python package installation failed**
```cmd
# Check requirements.txt file exists
# Verify internet connectivity
# Try building with verbose output
docker-compose build --progress=plain
```

### n8n Issues

**Error: Cannot access n8n interface**
```cmd
# Check if container is running
docker-compose ps

# Check container logs
docker-compose logs n8n

# Restart n8n service
docker-compose restart n8n
```

**Error: Workflow import failed**
```cmd
# Verify JSON file is valid
# Try importing manually through n8n interface
# Check file permissions
```

### Web Interface Issues

**Error: Microphone not working**
- Check browser permissions for microphone
- Verify Windows privacy settings allow microphone access
- Try a different browser
- Check Windows audio input settings

**Error: Cannot connect to n8n**
- Verify n8n is running on port 5678
- Check firewall settings
- Try accessing http://localhost:5678 directly

## Performance Optimization

### For Microsoft Surface Devices

1. **Power Settings**: Set to "High Performance" mode
2. **Background Apps**: Disable unnecessary background applications
3. **Windows Updates**: Ensure Windows is up to date
4. **Thermal Management**: Ensure good ventilation during processing

### Docker Optimization

1. **Resource Allocation**: 
   - RAM: 6-8GB for Docker
   - CPU: All available cores
   - Disk: SSD recommended

2. **Image Management**:
   ```cmd
   # Clean up unused images
   docker system prune -a
   
   # Remove unused volumes
   docker volume prune
   ```

## Security Configuration

### Firewall Settings

If you encounter connection issues, you may need to allow Docker through Windows Firewall:

1. Open Windows Defender Firewall
2. Click "Allow an app or feature through Windows Defender Firewall"
3. Find and allow "Docker Desktop"
4. Ensure both Private and Public networks are checked

### Network Configuration

The system uses the following ports:
- **5678**: n8n web interface and webhook
- **8000**: Whisper API service

Ensure these ports are not blocked by antivirus or firewall software.

## Post-Installation Setup

### 1. Create Desktop Shortcuts

Create shortcuts for easy access:
- n8n Interface: http://localhost:5678
- Web Interface: file:///path/to/webapp/index.html

### 2. Configure Auto-Start (Optional)

To start services automatically with Windows:

1. Create a batch file `start-translation-system.bat`:
   ```batch
   @echo off
   cd /d "C:\path\to\speech-translation-system\docker"
   docker-compose up -d
   echo Services started successfully
   pause
   ```

2. Add to Windows startup folder or Task Scheduler

### 3. Backup Configuration

Create a backup of your working configuration:
```cmd
# Backup n8n workflows
docker-compose exec n8n tar -czf /tmp/n8n-backup.tar.gz /home/node/.n8n

# Copy to host
docker cp n8n-speech-translation:/tmp/n8n-backup.tar.gz ./n8n-backup.tar.gz
```

## Next Steps

After successful installation:

1. Read the [User Guide](USER_GUIDE.md) for detailed usage instructions
2. Review the [API Documentation](API.md) for integration options
3. Check the [Troubleshooting Guide](TROUBLESHOOTING.md) for common issues

## Support

If you encounter issues during installation:

1. Check the Docker Desktop logs
2. Verify all prerequisites are met
3. Review the troubleshooting section above
4. Check Windows Event Viewer for system errors

Remember to keep Docker Desktop running whenever you want to use the translation system.