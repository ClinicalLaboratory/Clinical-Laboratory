#!/usr/bin/env python3
"""
System Integration Test Script
Tests the complete speech translation pipeline
"""

import requests
import time
import json
import sys
from pathlib import Path

def test_service_health():
    """Test if all services are healthy"""
    print("🔍 Testing service health...")
    
    services = [
        ("n8n", "http://localhost:5678/healthz"),
        ("Whisper API", "http://localhost:8000/health")
    ]
    
    all_healthy = True
    for service_name, url in services:
        try:
            response = requests.get(url, timeout=10)
            if response.status_code == 200:
                print(f"✅ {service_name}: Healthy")
            else:
                print(f"❌ {service_name}: Unhealthy (Status: {response.status_code})")
                all_healthy = False
        except requests.exceptions.RequestException as e:
            print(f"❌ {service_name}: Connection failed - {e}")
            all_healthy = False
    
    return all_healthy

def test_language_support():
    """Test language support endpoint"""
    print("\n🌍 Testing language support...")
    
    try:
        response = requests.get("http://localhost:8000/languages", timeout=10)
        if response.status_code == 200:
            data = response.json()
            languages = data.get('languages', [])
            print(f"✅ Languages endpoint: {len(languages)} languages supported")
            print(f"   Sample languages: {', '.join(languages[:5])}...")
            return True
        else:
            print(f"❌ Languages endpoint failed: {response.status_code}")
            return False
    except requests.exceptions.RequestException as e:
        print(f"❌ Languages endpoint connection failed: {e}")
        return False

def test_text_translation():
    """Test text-only translation"""
    print("\n📝 Testing text translation...")
    
    test_data = {
        "text": "Hello, how are you today?",
        "target_language": "spanish"
    }
    
    try:
        response = requests.post(
            "http://localhost:8000/translate",
            json=test_data,
            headers={"Content-Type": "application/json"},
            timeout=30
        )
        
        if response.status_code == 200:
            result = response.json()
            print(f"✅ Text translation successful")
            print(f"   Original: {result.get('original_text', 'N/A')}")
            print(f"   Translation: {result.get('translated_text', 'N/A')}")
            print(f"   Detected Language: {result.get('detected_language', 'N/A')}")
            return True
        else:
            print(f"❌ Text translation failed: {response.status_code}")
            print(f"   Response: {response.text}")
            return False
    except requests.exceptions.RequestException as e:
        print(f"❌ Text translation connection failed: {e}")
        return False

def create_test_audio():
    """Create a simple test audio file using text-to-speech (if available)"""
    print("\n🎵 Creating test audio...")
    
    # For testing purposes, we'll create a simple WAV file with silence
    # In a real scenario, you would use actual audio content
    try:
        import numpy as np
        import wave
        
        # Create 2 seconds of silence at 16kHz
        sample_rate = 16000
        duration = 2
        samples = np.zeros(sample_rate * duration, dtype=np.int16)
        
        test_audio_path = Path("test_audio.wav")
        with wave.open(str(test_audio_path), 'wb') as wav_file:
            wav_file.setnchannels(1)  # Mono
            wav_file.setsampwidth(2)  # 16-bit
            wav_file.setframerate(sample_rate)
            wav_file.writeframes(samples.tobytes())
        
        print(f"✅ Test audio file created: {test_audio_path}")
        return test_audio_path
    except ImportError:
        print("⚠️  numpy/wave not available, skipping audio file creation")
        return None
    except Exception as e:
        print(f"❌ Failed to create test audio: {e}")
        return None

def test_n8n_webhook():
    """Test the n8n webhook endpoint"""
    print("\n🔗 Testing n8n webhook...")
    
    # Test with text data first
    test_data = {
        "text": "Hello world",
        "target_language": "spanish",
        "contentType": "text"
    }
    
    try:
        response = requests.post(
            "http://localhost:5678/webhook/speech-translate",
            data=test_data,
            timeout=30
        )
        
        if response.status_code == 200:
            result = response.json()
            print(f"✅ n8n webhook successful")
            print(f"   Success: {result.get('success', 'N/A')}")
            if result.get('success'):
                print(f"   Translation: {result.get('translated_text', 'N/A')}")
            return True
        else:
            print(f"❌ n8n webhook failed: {response.status_code}")
            print(f"   Response: {response.text}")
            return False
    except requests.exceptions.RequestException as e:
        print(f"❌ n8n webhook connection failed: {e}")
        return False

def test_docker_containers():
    """Test if Docker containers are running"""
    print("\n🐳 Testing Docker containers...")
    
    try:
        import subprocess
        result = subprocess.run(
            ["docker-compose", "ps", "--format", "json"],
            cwd="docker",
            capture_output=True,
            text=True,
            timeout=10
        )
        
        if result.returncode == 0:
            containers = []
            for line in result.stdout.strip().split('\n'):
                if line.strip():
                    try:
                        container = json.loads(line)
                        containers.append(container)
                    except json.JSONDecodeError:
                        pass
            
            if containers:
                print(f"✅ Found {len(containers)} running containers:")
                for container in containers:
                    name = container.get('Name', 'Unknown')
                    status = container.get('State', 'Unknown')
                    print(f"   - {name}: {status}")
                return True
            else:
                print("❌ No containers found running")
                return False
        else:
            print(f"❌ Docker command failed: {result.stderr}")
            return False
    except subprocess.TimeoutExpired:
        print("❌ Docker command timed out")
        return False
    except FileNotFoundError:
        print("⚠️  Docker or docker-compose not found in PATH")
        return False
    except Exception as e:
        print(f"❌ Docker test failed: {e}")
        return False

def run_comprehensive_test():
    """Run all tests and provide summary"""
    print("🚀 Starting Speech Translation System Integration Test")
    print("=" * 60)
    
    tests = [
        ("Docker Containers", test_docker_containers),
        ("Service Health", test_service_health),
        ("Language Support", test_language_support),
        ("Text Translation", test_text_translation),
        ("n8n Webhook", test_n8n_webhook),
    ]
    
    results = {}
    for test_name, test_func in tests:
        try:
            results[test_name] = test_func()
        except Exception as e:
            print(f"❌ {test_name} test crashed: {e}")
            results[test_name] = False
        
        time.sleep(1)  # Brief pause between tests
    
    # Summary
    print("\n" + "=" * 60)
    print("📊 TEST SUMMARY")
    print("=" * 60)
    
    passed = sum(1 for result in results.values() if result)
    total = len(results)
    
    for test_name, result in results.items():
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status} {test_name}")
    
    print(f"\nOverall: {passed}/{total} tests passed")
    
    if passed == total:
        print("\n🎉 All tests passed! Your speech translation system is ready to use.")
        print("\nNext steps:")
        print("1. Open http://localhost:5678 to access n8n")
        print("2. Import the workflow from n8n-workflows/speech-translation-workflow.json")
        print("3. Open webapp/index.html in your browser")
        print("4. Start translating speech!")
    else:
        print(f"\n⚠️  {total - passed} test(s) failed. Please check the issues above.")
        print("\nTroubleshooting:")
        print("1. Ensure Docker Desktop is running")
        print("2. Run: docker-compose up -d (in the docker directory)")
        print("3. Wait 30-60 seconds for services to initialize")
        print("4. Check logs: docker-compose logs")
    
    return passed == total

if __name__ == "__main__":
    success = run_comprehensive_test()
    sys.exit(0 if success else 1)